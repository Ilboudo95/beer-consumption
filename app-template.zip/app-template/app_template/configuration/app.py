"""Application environment configuration."""
import os
import logging
import yaml


class AppConfig:
    """Load application environment configuration, e.g. credentials, logging."""

    _logging_conf_filepath = os.path.join(os.environ["UNXCONF"], "logging.conf.yml")
    _application_filepath = os.path.join(os.environ["UNXCONF"], "application.yml")

    def __init__(self):
        """Initialize application configuration.

        The 'application.yml' file is a symlink to one of the following conf files,
        which all have different credentials:
            - development.yml
            - preproduction.yml

        """
        self._prepare_logging()
        logging.info("============================================================")
        logging.info("============================================================")
        logging.info(f"  AppConfig in '{self._application_filepath}'")
        try:
            with open(self._application_filepath) as f:
                self._application_config = yaml.load(f.read(), Loader=yaml.FullLoader)
            self._prepare_postgres_configuration()
            self._prepare_mail_configuration()
        except FileExistsError:
            pass

    @property
    def postgres_config(self):
        """BRC database configuration."""
        return self._postgres_config

    @property
    def mail_config(self):
        """Mail configuration."""
        return self._mail_config

    def _prepare_logging(self):
        """Load logging configuration.

        The logging file is a timebased rotating file.

        """
        # Create log directory
        try:
            if not os.path.exists(os.environ["UNXLOG"]):
                os.makedirs(os.environ["UNXLOG"])
        except FileExistsError:
            pass

        # Create logging config
        with open(self._logging_conf_filepath) as f:
            dict_conf = yaml.load(f.read(), Loader=yaml.FullLoader)
            # Add filename
            prefix = os.environ["UNXPACKAGE"].replace("_", "-")
            for handler in dict_conf["handlers"].keys():
                if handler.startswith("file"):
                    filename = f"{prefix}-{handler.split('_')[1]}.log"
                    dict_conf["handlers"][handler][
                        "filename"
                    ] = f"{os.environ['UNXLOG']}/{filename}"

            import logging.config
            logging.config.dictConfig(dict_conf)

    def _prepare_postgres_configuration(self):
        logging.info("  - Loading brcdb configuration")

        # Check 'postgresql' section
        if "postgresql" not in self._application_config:
            raise KeyError(f"'postgresql' section not found in {self._application_filepath}")
        postgres_config = self._application_config["postgresql"]

        if "host" not in postgres_config:
            raise KeyError("missing 'host' definition in postgresql configuration")
        if "dbname" not in postgres_config:
            raise KeyError("missing 'dbname' definition in postgresql configuration")
        if "user" not in postgres_config:
            raise KeyError("missing 'user' definition in postgresql configuration")
        if "password" not in postgres_config:
            raise KeyError("missing 'password' definition in postgresql configuration")
        if "port" not in postgres_config:
            raise KeyError("missing 'port' definition in postgresql configuration")

        self._postgres_config = postgres_config

    def _prepare_mail_configuration(self):
        logging.info("  - Loading mail configuration")

        # Check 'mail' section
        if "mail" not in self._application_config:
            raise KeyError(f"'mail' section not found in {self._application_filepath}")
        mail_config = self._application_config["mail"]

        # Check mail credentials
        if "host" not in mail_config:
            raise KeyError("missing 'host' definition in 'mail' configuration")
        if "sender" not in mail_config:
            raise KeyError("missing 'sender' definition in 'mail' configuration")
        if "to_recipients" not in mail_config:
            raise KeyError("missing 'to_recipients' definition in 'mail' configuration")
        if "cc_recipients" not in mail_config:
            raise KeyError("missing 'cc_recipients' definition in 'mail' configuration")
        if "user" not in mail_config:
            raise KeyError("missing 'user' definition in 'mail' configuration")
        if "password" not in mail_config:
            raise KeyError("missing 'password' definition in 'mail' configuration")

        self._mail_config = mail_config
