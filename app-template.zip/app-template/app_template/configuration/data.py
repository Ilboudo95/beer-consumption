"""Application data configuration."""
import os
import logging
import json
import pandas as pd


class DataConfig:
    """Retrieve information from the configuration files located in ./resources directory."""

    _input_path = os.path.abspath(
        os.path.join(
            os.path.dirname(__file__), "resources"
        )
    )
    _correspondance_filepath = os.path.join(_input_path, "correspondance_name_id.csv")

    def __init__(self):
        """Initialize data configuration."""
        logging.info(f"  DataConfig in directory '{self._input_path}'")
        self._prepare_correspondance_configuration()

    def _prepare_correspondance_configuration(self):
        """Load the datamap configuration."""
        logging.info("  - Loading datamap")
        self._datamap = pd.read_csv(
            self._correspondance_filepath, dtype=str, sep=";", encoding="latin1"
        )
