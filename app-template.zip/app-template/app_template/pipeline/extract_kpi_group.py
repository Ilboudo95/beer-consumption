import logging
import datetime

from app_template.infra.repositories import opco_csv2pg, kpi_group_daily, kpi_group_monthly
from app_template.configuration import app
from app_template.utils.pg_utility import PgUtility as pg2Use
from app_template.utils import system


def extract_kpi():
    # Configuration

    dt_start = datetime.datetime.now()
    app_config = app.AppConfig()
    user = app_config.postgres_config["user"]
    host = app_config.postgres_config["host"]
    dbname = app_config.postgres_config["dbname"]
    password = app_config.postgres_config["password"]
    port = app_config.postgres_config["port"]
    port = str(port)
    logging.info(f"connection to data base {dbname}")
    tdbp173lv = pg2Use(host=host, dbname=dbname, user=user, password=password,port=port)

    # extract opco csv files from sftp to Postgresql DB.
    opco_csv2pg.extract_opco_csv(tdbp173lv)

    ## extract daily kpis from raw DB
    kpi_group_daily.extract_daily(tdbp173lv)

    # extract monthly kpis from raw db
    kpi_group_monthly.extract_monthly(tdbp173lv)

    # Execution time
    execution_time = system.get_execution_time(dt_start, datetime.datetime.now())
    logging.info(f"Duration: {execution_time}")


if __name__ == "__main__":
    extract_kpi()
