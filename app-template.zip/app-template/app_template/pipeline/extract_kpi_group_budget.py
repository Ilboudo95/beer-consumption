from app_template.utils.pg_utility import PgUtility as pg2Use
from app_template.configuration import app
from app_template.utils.other_utility import nbspecifique
import datetime
import sys


def check_connection(pg2Use):
    app_config = app.AppConfig()
    user = app_config.postgres_config["user"]
    host = app_config.postgres_config["host"]
    dbname = app_config.postgres_config["dbname"]
    password = app_config.postgres_config["password"]
    port = str(app_config.postgres_config["port"])
    tdbp173lv = pg2Use(host=host, dbname=dbname, user=user, password=password,port=port)
    return tdbp173lv


def extract_budget(filepath="budget4.csv"):
    dt_start = datetime.datetime.now()
    tdbp173lv = check_connection(pg2Use)

    if tdbp173lv.Connecting():
        print('conneted successufly !!!')
        #start bulk insert
        table_name = "budget_kpi_groupe"
        #set the full path of budget csv filename 
        createTmpCsv = tdbp173lv.addColumnInDf(filepath,columnvaluename='budget_value',addcol=False,delimiter=';')
        if createTmpCsv:
            if tdbp173lv.Bulkcsv(tableName=table_name):
                print('budget inserted in tmp table')
                query = """
                select id, date, kpi_id,
                (budget_value*1000::float/extract(DAY FROM date)::float)::float as budget_daily,
                budget_value *1000 as budget_monthly, code_pays from budget_kpi_groupe;
                """
                data = tdbp173lv.ExcecuteSomeQuery(query)
                table_name="tb_budget_kpi_axian"
                uk_key = "uk_tb_budget_kpi_axian"
                if len(data) > 0 :
                    for row in data:
                        data_ ={}
                        id = row.get('id')
                        data_['kpi_id'] = str(row.get('kpi_id'))
                        data_['budget_daily'] = nbspecifique(row.get('budget_daily')) #budget_monthly
                        data_['budget_monthly'] = nbspecifique(row.get('budget_monthly'))
                        data_['code_pays'] = str(row.get('code_pays'))
                        data_['date'] = str(row.get('date'))
                        data_.update({"updatedcolumn": ['budget_daily','budget_monthly']})            
                        #continue
                        if tdbp173lv.UpsertIt(data_, table_name,uk_key, updateifexist = True):
                            deletesql = f"""
                                DELETE  FROM budget_kpi_groupe
                                WHERE 
                                id ={id}
                            """
                            if tdbp173lv.ExcecuteSomeQuery(deletesql,typ ='d'):
                                print('status : done')
                            continue
                else:
                    print(f'{table_name} is empty !!')
                    print('')
        else:
            print("failed to load temporary csv file")
            sys.exit()

if __name__ == "__main__":
    extract_budget()
