from datetime import datetime
import os
from other_utility import ensure_dir

class DeviceLogger:
    def __init__(self, logdirectory, logname):
        current_day = '{:%Y_%m_%d}'.format(datetime.now())
        current_time = '{:%H_%M}'.format(datetime.now())
        self.log_dir = ensure_dir(os.path.join(logdirectory,current_day))
        self.log_name = logname +"_"+current_time + "_.log"
        self.log_path = os.path.join(self.log_dir, self.log_name)

    # message = message to log or exception object if is_exception = True
    # is_exception = True if message = exception object
    # level: "EXCEPTION" / "ERROR" / "WARNING" / None ("INFO")

    def write_to_log_file(self, message, is_exception, level="INFO"):
        if is_exception:
            message = "{} {}".format(str(type(message).__name__), str(message.args))
        current_day_time = '{:%Y_%m_%d_%H_%M_%S}'.format(datetime.now())
        with open(self.log_path,"a") as file:
            file.write("{}: [{}] {}".format(current_day_time, level, message))
            file.write("\n")
        

        

