import glob
import os
import errno
import shutil
import csv
from pathlib import Path
import re
import logging
from datetime import datetime

def ensure_dir(directory):
    if not os.path.exists(directory):
        try:
            os.umask(0)
            os.makedirs(directory, 0o777)
        except OSError as exc:
            if exc.errno != errno.EEXIST:
                raise


def recupAllFileInpattern(path_, pattern_):
    patternok = os.path.join(path_, pattern_)  
    listo = glob.glob(patternok)
    for pathtofile in listo:
        yield pathtofile


def rename_file_exist(filename):
    status = False
    csvoldfile =  str(datetime.now().strftime("_%Y-%m-%d_%H_%M_%S")) + '.csv'
    if os.path.isfile(filename):
        try:
            os.rename(filename, filename.replace(".csv", csvoldfile))
            status = True
        except Exception as e:
            print(e)
            logging.info(e)
    else:
        status = True
    return status


def moveFile(source, destination):
    dest = None
    try:
        dest = shutil.move(source, destination)
        logging.info(f"{source} are well moved to {dest}")
    except Exception as e:
        print (e)
        logging.warning(e)
    return dest


def checkEmptyFile(filepath):
    return os.stat(filepath).st_size == 0

def checkIfCsvAsAnHeader(csvfile):
    if not checkEmptyFile(csvfile):
        with open(csvfile, 'rb') as csvfile:
            sniffer = csv.Sniffer()
            return sniffer.has_header(csvfile.read(2048))
            #csvfile.seek(0)


def nbspecifique(nb):
    try:
        nb = float(nb)
    except Exception as e:
        print(e)
        nb = '0'
    return str(int(nb)) if str(nb) !='nan' else '0'

def checkCSVTypeKpi(filename_):
    filedecoup = str(filename_).lower().split('_')
    tablename = None
    if 'daily' in filedecoup :
        tablename = "opco_csv_daily"
    elif 'monthly' in filedecoup:
        tablename = "opco_csv_monthly"
    return tablename


def extract_filename_and_create_directory(filename, racine):
    date2use = re.search("([0-9]{4}\_[0-9]{2})", filename)
    pathok = None
    if date2use:
        annee, moi = date2use.split('_')
        pathcreated = os.path.join(annee, moi)
        fullpath2createifnotexist = os.path.join(racine, pathcreated)
        Path(rf"{fullpath2createifnotexist}").mkdir(parents=True, exist_ok=True)
        pathok = fullpath2createifnotexist
    return pathok


