import psycopg2
import psycopg2.extras
import psycopg2.extensions
import pandas as pd 
from colorama import Fore
import numpy as np
import os
import logging
#from DeviceLogger import DeviceLogger

from app_template.utils.other_utility import checkEmptyFile


class PgUtility():
    def __init__(self, host='localhost', dbname='db_telco_axian', user='telco_axian', password='123456',port='5432'):
        self.tmpfile = None
        self.hostname = host
        self.dbname = dbname
        self.user = user
        self.password = password
        self.port = port
        self.delimiter = ','

    def Connecting(self):
        nb_tentative = 1        
        retour = False
        while nb_tentative < 4 :            
            print (Fore.GREEN + f"trying to connect in to {self.hostname} #Tentative Number : {nb_tentative} ")
            logging.info(f"trying to connect in to {self.hostname} #Tentative Number : {nb_tentative} ")
            try:
                self.con = psycopg2.connect('host='+self.hostname+' port='+self.port +' dbname='+self.dbname+' user='+self.user+' password='+ self.password)
                self.con.set_isolation_level(0)
                self.curseur = self.con.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                self.con.set_client_encoding('WIN1252')
                retour = True
                break 
            except Exception as  e:
                logging.info(e)
                print (Fore.RED + f"Impossible de se connecter a {self.hostname} voici les details:\n {e}")
                nb_tentative += 1
        return retour
        
    def Truncatetable(self, tableName):    
        try:
            sql =f"TRUNCATE TABLE {tableName} RESTART IDENTITY CASCADE;"
            self.curseur.execute(sql)
            print(Fore.GREEN + f"{tableName} truncated !!")
        except Exception as e:
            print(Fore.RED + f"can't truncate the table : {tableName}\n error details: {e}")
            
    def ExcecuteSomeQuery(self, sql, typ='s'):
              
        if str(typ).lower()=='u' or str(typ).lower()==('d') or str(typ).lower()==('i'):
            retour = False            
            try:
                self.curseur.execute(sql)
                self.con.commit()
                print(Fore.GREEN + f'{sql} is excecuted with success')
                retour = True
            except Exception as e:
                print (Fore.RED + f" an error is occured when executing this query :{sql} \nerror details : \n {e}")
            return retour
        else:
            
            try:
                self.curseur.execute(sql)
                return self.curseur.fetchall()
            except Exception as e:
                print (Fore.RED + f" an error is occured when executing this query :{sql} \nerror details : \n {e}")
                logging.error(f" an error is occured when executing this query :{sql} \nerror details : \n {e}")

    def __TraiterDictUpsert(self, dataupsert):
        updatedcolumn= None
        
        if isinstance(dataupsert, dict):
            try:
                updatedcolumn = ' SET ' + ",".join([column + ' = EXCLUDED.' + column for column in dataupsert.pop('updatedcolumn',None) if column ]) + ";"                               
            except Exception as e:
                print(Fore.RED + f"the updatedcolumn keys doesn't not exist in dictionary data => {e}")            
        return updatedcolumn   
     
    def __dict2query(self, dict_):
        column =  value = None
        if isinstance(dict_, dict):           
            column = ",".join(dict_.keys())
            dict_ = list(map(str,dict_.values()))            
            value = " VALUES ('"+"','".join(dict_)+"')"        
        return column, value    
        
    def UpsertIt(self, dictdata, tablename,
                 constraintName, updateifexist = True):
        """
        dictdata: list of dictionary data to insert in the tablename
        this parameter will be containt column to update where updateifexist = True
        constraintName: unik constraint to check 
        updateifexist: default true update record if exist        
        """
        retour = False
        print("Data to insert: ", dictdata)
              
        if updateifexist:
            do = " DO UPDATE "
            forupdate = self.__TraiterDictUpsert(dictdata)
            sql = f"INSERT INTO {tablename} "
            column, value = self.__dict2query(dictdata)
            sql +=f"({column}) {value}" 
            sql += f" ON CONFLICT ON CONSTRAINT {constraintName}  {do} {forupdate}"
        else:
            do = " DO NOTHING;"
            sql = f"INSERT INTO {tablename} "
            column, value = self.__dict2query(dictdata)
            sql +=f"({column}) {value}" 
            sql += f" ON CONFLICT ON CONSTRAINT {constraintName} {do}"
        print("sql to execute ",sql)
        try:

            self.curseur.execute(sql)
            self.con.commit()
            retour = True
        except Exception as e:
            print(Fore.RED + str(e))
        return retour

    def addColumnInDf(self,csvfile,columnvaluename = 'kpi_value',addcol=True, coluname2add='code_pays', defaultValueofColumn ='Zero',delimiter=','):
        retour = False
        tmpcsv = './tmp_opco_groupan.csv'
        self.delimiter = delimiter
        if not checkEmptyFile(csvfile):
            try:
                df = pd.read_csv(csvfile, sep=self.delimiter)
                df= df.rename(columns=str.lower)
                #normalize date format to YYYY-MM-DD
                df['date']=pd.to_datetime(df['date'], infer_datetime_format='%Y-%m-%d')
                #ensure that kpi_value as an flot and camma (,) as separated
                
                df[columnvaluename] = pd.to_numeric(df[columnvaluename].astype(str).str.replace(',','.'),  errors='coerce',downcast="float")

                #df['kpi_value'].apply(np.ceil)#.round(decimals=2)
                if addcol:
                    df[coluname2add] = defaultValueofColumn
                print('csv formted data: ',df.to_dict('records'))
                csvheader = ",".join(list(df.columns))
                df.to_csv(tmpcsv, sep=self.delimiter,index=False)
                self.tmpfile = tmpcsv
                print(self.tmpfile)
                retour = True
            except Exception as e:
                print(' error *** ', e)
        else:
            print(Fore.RED + f' [!] {csvfile} is empty')
        return retour 

    def Bulkcsv(self, tableName='test_tb'):
        retour = False
        csvheader=None             
        try:
            df = pd.read_csv(self.tmpfile, sep=self.delimiter)                        
            csvheader = ",".join(list(df.columns))
            copy_sql = f"""
            COPY {tableName} ({csvheader}) FROM stdin WITH CSV HEADER
            DELIMITER as '{self.delimiter}' ENCODING 'UTF8'
            """
            with open(self.tmpfile, 'r') as f:
                self.curseur.copy_expert(sql=copy_sql, file=f)
                self.con.commit()
            os.remove(self.tmpfile)
            self.tmpfile = None
            retour = True
        except Exception as e:
            print (e)

        return retour   
        
    def Closeall(self):
        self.curseur.close()
        self.con.close()

    def checkAnomalieInCsv(self,csv_file_path,delimitaka=';'):
        dfb = False
        try:
            df = pd.read_csv(csv_file_path, sep=delimitaka)
            sql_ = "SELECT DISTINCT(kpi_id) FROM dim_kpi_groupe"
            dat = pd.read_sql_query(sql_, self.con)
            #check if csv kpi_id exist in our database (table)
            df['kpi_idIsmatch'] = np.where(df['kpi_id'] == dat['kpi_id'], 'True', 'False')
            dfb = True          
        except Exception as e:
            print(e)
        if dfb:
            return df
        return None

        

if __name__ == "__main__":
    PgUtility = PgUtility(dbname="BIDATA")
    if PgUtility.Connecting():
        #test.UpsertIt({"nom": "rayman", "prenom":"june","age":"27","datenaissance":"ts miova", "updatedcolumn":['age','datenaissance']}, "contact","nomprenom", updateifexist = True)
        #test.UpsertIt({"nom": "rayman", "prenom":"june","age":"27","datenaissance":"ts miova"}, "contact","nomprenom", updateifexist = False)
        PgUtility.Bulkcsv('MOCK_DATA.csv','contact') #ok
        #test.Truncatetable('contact')
