from dateutil.relativedelta import relativedelta


def get_execution_time(start, end):
    """Get the time between two timestamps in human readable format.

    Parameters
    ----------
    start : datetime.datetime
        Start datetime.
    end : datetime.datetime
        End datetime.

    """
    rd = relativedelta(end, start)
    return "%d hours, %d minutes and %d seconds" % (rd.hours, rd.minutes, rd.seconds)
