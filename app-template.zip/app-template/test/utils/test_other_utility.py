import os
import pytest
# import pandas as pd
# from pandas.testing import assert_series_equal

from extraction_data_zattoo.utils import other_utility


def test_nbspecifique():
    nb = 10.3
    actual = other_utility.nbspecifique(nb)
    assert actual == "10"


def test_nbspecifique_nan():
    nb = "nan"
    actual = other_utility.nbspecifique(nb)
    assert actual == "0"
